package com.nttdata.account_service.domain;


public enum AccountType {
    SAVINGS,    // Ahorro
    CURRENT,    // Corriente
    FIXED_TERM  // Plazo fijo
}