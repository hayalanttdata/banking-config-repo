package com.nttdata.account_service.domain;

public enum CustomerProfile {
    PERSONAL_STANDARD,
    PERSONAL_VIP,
    BUSINESS_STANDARD,
    BUSINESS_PYME
}