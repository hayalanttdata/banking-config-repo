package com.nttdata.account_service.domain;

public enum CustomerType {
    PERSONAL,
    BUSINESS
}