package com.nttdata.transaction_service.domain;

public enum TransactionType {
    DEPOSIT,
    WITHDRAW,
    TRANSFER_IN,
    TRANSFER_OUT,
    FEE
}